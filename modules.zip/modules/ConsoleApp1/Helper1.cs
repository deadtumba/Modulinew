﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.Web;
using ConsoleApp1.Models1;
namespace ConsoleApp1
{
    class Helper1
    {
        private static Entities11 s_entities1;
        public static Entities11 GetContext()
        {
            if(s_entities1 == null)
            {
                s_entities1 = new Entities11();
            }
            return s_entities1;
        }
        public void CreateUsers(Autorizacia user)
        {
            s_entities1.Autorizacia.Add(user);
            s_entities1.SaveChanges();
        }
        public void UpdateUsers(Autorizacia user)
        {
            s_entities1.Entry(user).State = EntityState.Modified;
            s_entities1.SaveChanges();
        }
        public void RemoveUsers(int idUsers)
        {
            var users = s_entities1.Autorizacia.Find(idUsers);
            s_entities1.Autorizacia.Remove(users);
            s_entities1.SaveChanges();
        }
        public void FiltrUsers()
        {
            var users = s_entities1.Autorizacia.Where(x => x.Login.StartsWith("a") || x.Login.StartsWith("z"));
        }
        public void SortUsers()
        {
            var users = s_entities1.Autorizacia.OrderBy(x => x.Login);
        }

    }
}
